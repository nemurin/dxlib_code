#include "DxLib.h"
#include "grobalvalue.h"
void img_sound_load() {
	img_player = LoadGraph("Graphics/jiki.png");
	img_background = LoadGraph("Graphics/Background.png");
}