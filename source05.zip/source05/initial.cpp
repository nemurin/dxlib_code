#include "DxLib.h"
#include "grobalvalue.h"


void initialization() {
	Player.x = 200.0;
	Player.y = 400.0;
}
