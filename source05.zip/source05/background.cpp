#include "DxLib.h"
#include "grobalvalue.h"

void Background() {
	DrawGraph(0, 0, img_background, FALSE);
}