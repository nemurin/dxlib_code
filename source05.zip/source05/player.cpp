#include "DxLib.h"
#include "grobalvalue.h"
void PlayerControl() {
	DrawGraph(Player.x, Player.y, img_player, TRUE);
}